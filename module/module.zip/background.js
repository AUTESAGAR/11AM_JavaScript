export function change(){
    document.querySelector("body").style.background="cyan";
}