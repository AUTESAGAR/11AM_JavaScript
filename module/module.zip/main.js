import {change} from './background.js';

document.getElementById("bg").addEventListener("click",change);